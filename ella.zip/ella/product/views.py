from django.shortcuts import render

# Create your views here.
def product(request):
    context = {}
    return render(request, 'product/product.html')

def main(request):
    context = {}
    return render(request, 'product/main.html')